import 'package:aula_database_and_api/todo.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'constants.dart';

class DataBaseService {
  Future<Database> get _db async {
    return openDatabase(
      join(await getDatabasesPath(), dataBaseName),
      version: 2,
      onCreate: (db, version) {
        return db.execute(scriptCreateTable);
      },
    );
  }

  //Create
  Future<void> insertTodo(Todo value) async {
    final db = await _db;
    db.insert(tableName, value.toJson(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  //Read
  Future<List<Todo>> listTodo() async {
    final db = await _db;
    final List<Map<String, dynamic>> todoJson = await db.query(tableName);
    final List<Todo> todos = todoJson.map((e)=> Todo.fromJson(e)).toList();
    return todos;
  }

  //Update
  Future<void> updateTodo(Todo value) async {
    final db = await _db;
    await db.update(
      tableName,
      value.toJson(),
      where: 'id = ?',
      whereArgs: [value.id],
    );
  }

  //Delete
  Future<void> deleteTodo(Todo todo) async {
    final db = await _db;
    if (todo.id == null) return;
    await db.delete(
      tableName,
      where: 'id = ?',
      whereArgs: [todo.id],
    );
  }
}
