import 'package:aula_database_and_api/constants.dart';
import 'package:dio/dio.dart';

class ApiService {
  final Dio _dio = Dio(
    BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
      headers: {'Content-Type': 'application/json'},
    ),
  );

  /// Lista todas as tarefas (GET)
  Future<List<dynamic>> getTodos() async {
    try {
      final response = await _dio.get('/todos');
      return response.data;
    } catch (e) {
      throw Exception('Erro ao buscar tarefas: $e');
    }
  }

  /// Cria uma nova tarefa (POST)
  Future<void> createTodo(Map<String, dynamic> data) async {
    try {
      await _dio.post('/todos', data: data);
    } catch (e) {
      throw Exception('Erro ao criar tarefa: $e');
    }
  }

  /// Atualiza uma tarefa existente (PUT)
  Future<void> updateTodo(int id, Map<String, dynamic> data) async {
    try {
      await _dio.put('/todos/$id', data: data);
    } catch (e) {
      throw Exception('Erro ao atualizar tarefa: $e');
    }
  }

  /// Remove uma tarefa (DELETE)
  Future<void> deleteTodo(int id) async {
    try {
      await _dio.delete('/todos/$id');
    } catch (e) {
      throw Exception('Erro ao excluir tarefa: $e');
    }
  }

  /// Exemplo opcional: trata erros de forma mais elegante
  void handleError(DioException error) {
    if (error.response != null) {
      final statusCode = error.response?.statusCode;
      final message = error.response?.data ?? 'Erro desconhecido';
      throw Exception('Erro $statusCode: $message');
    } else {
      throw Exception('Falha na conexão: ${error.message}');
    }
  }
}
