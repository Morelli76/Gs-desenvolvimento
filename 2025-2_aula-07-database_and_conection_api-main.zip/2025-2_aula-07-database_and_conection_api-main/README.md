# Aula 05/11 — Banco de Dados & Conexão com API

**Implementação prática de persistência local com SQLite e integração com API utilizando o pacote Dio.**

---

## 📚 Conteúdo

- 📦 **SQLite** — persistência local de dados
- 🌐 **Dio** — comunicação com API REST
- 🧩 **CRUD completo** (Create, Read, Update, Delete)
- 🧱 **Arquitetura MVVM** — separando camadas (Model, ViewModel e Service)
- 🧠 **Sincronização entre banco local e API**

---

## 🚀 Como executar

```bash
# Crie um novo projeto Flutter
flutter create todo_app_fiap
cd todo_app_fiap

# Adicione as dependências
flutter pub add provider sqflite sqflite_common_ffi path dio

# Execute o app
flutter run
```

---

## 🧩 Estrutura do projeto

```
lib/
 ┣ 📂 models/        → classe Todo
 ┣ 📂 services/      → database_service.dart e api_service.dart
 ┣ 📂 viewmodel/     → home_view_model.dart
 ┣ 📂 widgets/       → add_todo_bottom_sheet.dart
 ┗ 📄 main.dart
```

💡 Essa separação facilita a manutenção, os testes e a reutilização de código.

---

## 💾 Exemplo: classe Todo

```dart
class Todo {
  final int? id;
  final String title;
  final bool done;

  Todo({
    this.id,
    required this.title,
    this.done = false,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'done': done ? 1 : 0,
  };

  factory Todo.fromJson(Map<String, dynamic> json) => Todo(
    id: json['id'],
    title: json['title'],
    done: json['done'] == 1,
  );

  Todo copyWith({int? id, String? title, bool? done}) {
    return Todo(
      id: id ?? this.id,
      title: title ?? this.title,
      done: done ?? this.done,
    );
  }
}
```

---

## 🧱 Banco de Dados Local (SQLite)

```dart
class DataBaseService {
  Future<Database> get _db async {
    return openDatabase(
      join(await getDatabasesPath(), 'fiap_todo.db'),
      version: 1,
      onCreate: (db, version) {
        return db.execute('''
          CREATE TABLE todos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            done INTEGER
          )
        ''');
      },
    );
  }

  Future<void> insertTodo(Todo value) async {
    final db = await _db;
    db.insert('todos', value.toJson(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Todo>> listTodo() async {
    final db = await _db;
    final List<Map<String, dynamic>> todoJson = await db.query('todos');
    return todoJson.map((e) => Todo.fromJson(e)).toList();
  }

  Future<void> updateTodo(Todo value) async {
    final db = await _db;
    db.update('todos', value.toJson(),
        where: 'id = ?', whereArgs: [value.id]);
  }

  Future<void> deleteTodo(int id) async {
    final db = await _db;
    db.delete('todos', where: 'id = ?', whereArgs: [id]);
  }
}
```

---

## 🌐 Comunicação com API (Dio)

```dart
class ApiService {
  final Dio _dio = Dio(BaseOptions(baseUrl: 'https://seuservidor.com/api/fiap'));

  Future<List<Todo>> fetchTodos() async {
    final response = await _dio.get('/todos');
    return (response.data as List)
        .map((e) => Todo.fromJson(e))
        .toList();
  }

  Future<void> createTodo(Todo todo) async {
    await _dio.post('/todos', data: todo.toJson());
  }

  Future<void> updateTodo(Todo todo) async {
    await _dio.put('/todos/${todo.id}', data: todo.toJson());
  }

  Future<void> deleteTodo(int id) async {
    await _dio.delete('/todos/$id');
  }
}
```

---

## 🧠 Boas práticas

- Use **MVVM**: mantenha o banco e a API isolados na camada *service*.
- Prefira o **Provider** para o gerenciamento de estado.
- Sempre valide se o banco foi criado antes de inserir dados.
- Use **try/catch** nas chamadas de rede com Dio.
- Utilize o método **copyWith()** para atualizar apenas campos necessários.

---

## 💡 Exercícios

1️⃣ Crie um botão que marca todas as tarefas como concluídas.  
2️⃣ Adicione um botão para limpar todas as tarefas concluídas.  
3️⃣ Sincronize automaticamente com a API ao abrir o app.  
4️⃣ Exiba um indicador de progresso (`CircularProgressIndicator`) enquanto carrega.  
5️⃣ Adicione um campo de busca para filtrar tarefas.

---

## 🧪 Dica Extra

Para testar a integração, você pode usar o **backend Laravel** da aula:
```
http://127.0.0.1:8000/api/fiap/todos
```

Ou o endpoint de produção:
```
https://seuservidor.com/api/fiap/todos
```

---

## 🧩 Recursos

- 🔗 [Documentação Flutter](https://docs.flutter.dev)
- 🔗 [Dio no pub.dev](https://pub.dev/packages/dio)
- 🔗 [Sqflite no pub.dev](https://pub.dev/packages/sqflite)
- 🔗 [Provider no pub.dev](https://pub.dev/packages/provider)
- 🔗 [Repositório do Professor](https://github.com/profcarlosadao)
